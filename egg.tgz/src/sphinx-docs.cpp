// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "sphinx docs");
  std::fflush(stdout);
  return lionss_run_workload("sphinx-docs");
}
