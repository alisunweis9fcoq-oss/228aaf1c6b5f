// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("man pages"); }
int main(){
  announce();
  return lionss_run_workload("man-pages");
}
