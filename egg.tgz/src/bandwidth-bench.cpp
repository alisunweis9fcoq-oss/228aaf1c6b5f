// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("bandwidth bench\n", stdout);
  return lionss_run_workload("bandwidth-bench");
}
