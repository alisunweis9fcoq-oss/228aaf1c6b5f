// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("perf stat"); }
int main(){
  announce();
  return lionss_run_workload("perf-stat");
}
