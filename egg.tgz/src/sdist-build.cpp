// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sdist build"); }
int main(){
  announce();
  return lionss_run_workload("sdist-build");
}
