// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("end to end"); }
int main(){
  announce();
  return lionss_run_workload("end-to-end");
}
