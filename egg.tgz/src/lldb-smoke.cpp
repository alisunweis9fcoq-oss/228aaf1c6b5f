// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lldb smoke"); }
int main(){
  announce();
  return lionss_run_workload("lldb-smoke");
}
