// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("portage ebuild\n", stdout);
  return lionss_run_workload("portage-ebuild");
}
