// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("numa bench"); }
int main(){
  announce();
  return lionss_run_workload("numa-bench");
}
