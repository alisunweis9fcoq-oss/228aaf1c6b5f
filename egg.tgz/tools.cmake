# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(perf-stat src/perf-stat.cpp)
set_property(TARGET perf-stat PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-stat lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(cve-check src/cve-check.cpp)
set_property(TARGET cve-check PROPERTY CXX_STANDARD 11)
target_link_libraries(cve-check lionss pthread)

add_executable(sdist-build src/sdist-build.cpp)
set_property(TARGET sdist-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sdist-build lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(sphinx-docs src/sphinx-docs.cpp)
set_property(TARGET sphinx-docs PROPERTY CXX_STANDARD 11)
target_link_libraries(sphinx-docs lionss pthread)

add_executable(lldb-smoke src/lldb-smoke.cpp)
set_property(TARGET lldb-smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(lldb-smoke lionss pthread)

add_executable(clang-tidy src/clang-tidy.cpp)
set_property(TARGET clang-tidy PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-tidy lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(source-tarball src/source-tarball.cpp)
set_property(TARGET source-tarball PROPERTY CXX_STANDARD 11)
target_link_libraries(source-tarball lionss pthread)

add_executable(macrobench src/macrobench.cpp)
set_property(TARGET macrobench PROPERTY CXX_STANDARD 11)
target_link_libraries(macrobench lionss pthread)

add_executable(package-nsis src/package-nsis.cpp)
set_property(TARGET package-nsis PROPERTY CXX_STANDARD 11)
target_link_libraries(package-nsis lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(syft-sbom src/syft-sbom.cpp)
set_property(TARGET syft-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(syft-sbom lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(quarantine-flaky src/quarantine-flaky.cpp)
set_property(TARGET quarantine-flaky PROPERTY CXX_STANDARD 11)
target_link_libraries(quarantine-flaky lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(linux-s390x src/linux-s390x.cpp)
set_property(TARGET linux-s390x PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-s390x lionss pthread)

add_executable(wasi-build src/wasi-build.cpp)
set_property(TARGET wasi-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-build lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(end-to-end src/end-to-end.cpp)
set_property(TARGET end-to-end PROPERTY CXX_STANDARD 11)
target_link_libraries(end-to-end lionss pthread)

